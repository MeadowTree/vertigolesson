﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace LessonBasic
{
    public class FirstLessonScript : MonoBehaviour
    {
        // Start is called before the first frame update
        [SerializeField]
        int tamSayi = 1;
        [SerializeField]
        int tamSayi2 = 100;
        float ondalikSayi = 0.25f;
        float ondalikSayi2 = 1.25f;
        bool dogru = true;
        bool yanlis = false;
        [SerializeField] private Vector3 ucFloat = new Vector3(3, 3, 3);



        void Start()
        {

        }

        // Update is called once per frame
        void Update()
        {

        }
    }
}


